INSERT INTO osoba (id,name,age,gender) VALUES ('1','Pero','32','M');
INSERT INTO osoba (id,name,age,gender) VALUES ('2','Duro','12','M');
INSERT INTO osoba (id,name,age,gender) VALUES ('3','Mijo','15','M');
